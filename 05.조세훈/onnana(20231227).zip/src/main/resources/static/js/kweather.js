[
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_idx_carwash.png?ver=20231201",
        "생활지수": "세차지수",
        "지수": 70,
        "안내멘트": "비교적 걱정 없이 세차할 수 있어요"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_idx_running.png?ver=20231201",
        "생활지수": "달리기지수",
        "지수": 55,
        "안내멘트": "오늘은 달리기 보단 가벼운 산책 추천"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_idx_washing.png?ver=20231201",
        "생활지수": "빨래지수",
        "지수": 54,
        "안내멘트": "문을 닫고 실내에서 말리는 것을 추천"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_idx_sleep.png?ver=20231201",
        "생활지수": "수면지수",
        "지수": 30,
        "안내멘트": "수면을 위해 적정 온습도를 유지하세요"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_idx_umb.png?ver=20231201",
        "생활지수": "우산지수",
        "지수": 10,
        "안내멘트": "우산 없이 가볍게 외출하세요!"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_life_uv.png?ver=20231201",
        "생활지수": "자외선지수",
        "지수": 1,
        "안내멘트": "오늘은 안심하고 야외 활동하세요"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_life_cold.png?ver=20231201",
        "생활지수": "감기지수",
        "지수": 3,
        "안내멘트": "노약자는 외부 활동을 되도록 삼가요"
    },
    {
        "이미지": "https://www.kr-weathernews.com/mv3/img/icon_life_freez.png?ver=20231201",
        "생활지수": "동파지수",
        "지수": 25,
        "안내멘트": "큰 추위 없어 동파 걱정 없어요"
    }
]