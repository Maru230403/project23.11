package com.human.onnana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnnanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnnanaApplication.class, args);
	}

}
